package com.khrd.dto;

public class Room {
	private int roomNo; // 객실 호수
	private int roomPrice; // 객실 가격
//	private int rcNo; // 객실 분류 번호
	private RoomCategory roomCategory;
	private int vtNo; // 전망 타입 번호
	private int btNo; // 침대 타입 번호
	private int rsNo; // 객실 크기 번호
	
	public Room() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Room(int roomNo, int roomPrice, RoomCategory roomCategory, int vtNo, int btNo, int rsNo) {
		super();
		this.roomNo = roomNo;
		this.roomPrice = roomPrice;
		this.roomCategory = roomCategory;
		this.vtNo = vtNo;
		this.btNo = btNo;
		this.rsNo = rsNo;
	}

	public int getRoomNo() {
		return roomNo;
	}

	public void setRoomNo(int roomNo) {
		this.roomNo = roomNo;
	}

	public int getRoomPrice() {
		return roomPrice;
	}

	public void setRoomPrice(int roomPrice) {
		this.roomPrice = roomPrice;
	}

	public RoomCategory getRoomCategory() {
		return roomCategory;
	}

	public void setRoomCategory(RoomCategory roomCategory) {
		this.roomCategory = roomCategory;
	}

	public int getVtNo() {
		return vtNo;
	}

	public void setVtNo(int vtNo) {
		this.vtNo = vtNo;
	}

	public int getBtNo() {
		return btNo;
	}

	public void setBtNo(int btNo) {
		this.btNo = btNo;
	}

	public int getRsNo() {
		return rsNo;
	}

	public void setRsNo(int rsNo) {
		this.rsNo = rsNo;
	}

	@Override
	public String toString() {
		return "Room [roomNo=" + roomNo + ", roomPrice=" + roomPrice + ", roomCategory=" + roomCategory + ", vtNo="
				+ vtNo + ", btNo=" + btNo + ", rsNo=" + rsNo + "]";
	}

}// Room
